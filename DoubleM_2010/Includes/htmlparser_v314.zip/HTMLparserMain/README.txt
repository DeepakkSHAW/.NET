This is the open source release of HTMLparser - object created for 
use in Majestic-12 Distributed Search Engine project. Please be sure
to read and understand license in License.txt. By using this object,
checking source code etc you agree to abide by the terms of the License
agreement.

HTMLparser is a high performance HTML parser that allows to parse 
(tokenize) HTML. 

An example of use is in Main.cs. By default majestic12.html will be used 
in testing and benchmarking.

Some ToDo tasks are in todo.txt file.

Directory TESTS contains benchmark batch file and more.

Note: .NET 2.0 projects are for Visual Studio 2008.