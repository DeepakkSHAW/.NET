For Visual Studio 2003 open solution: HTMLparserMain\HTMLparserDotNet11.sln

For Visual Studio 2005 open solution: HTMLparserMain\HTMLparserDotNet11.sln 
(you will be prompted to convert it to VS 2005 project formats).
Also set conditional compilation symbol: DOTNET20 in HTMLparserLib project
-> Build options. 

For Visual Studio 2008 open solution: HTMLparserMain\HTMLparserDotNet20.sln 
(the target for compilation is still .NET 2.0)
