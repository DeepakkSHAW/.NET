bbc_russian.html - test for correct parsing of the Russian encoding.
majestic12.html - default HTML that will be parsed unless it is specified in command line